package com.cognizant.springlearn.bean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Depatrtment {
	private int id;
	private String name;
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(Employee.class);
	
	Depatrtment(){
		((org.slf4j.Logger) LOGGER).info("hiee");
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static Logger getLogger() {
		return LOGGER;
	}
	@Override
	public String toString() {
		return "Depatrtment [id=" + id + ", name=" + name + "]";
	}
	

}
