package com.cognizant.springlearn.bean;

//import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Employee {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Employee.class);
	
	private int id;
	private String name;
	private double salary;
	private Boolean permanent;
	private Date dateOfBirth;
	private Depatrtment department;
	private List<Skill> skills;
	
	public List<Skill> getSkills() {
		return skills;
	}
	public void setSkills(List<Skill> skills) {
		LOGGER.debug("inside set skill");
		this.skills=skills;
	}
	
	public Depatrtment getDepartment() {
		return department;
	}
	public void setDepartment(Depatrtment department) {
		this.department = department;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Boolean getPermanent() {
		return permanent;
	}
	public void setPermanent(Boolean permanent) {
		this.permanent = permanent;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", permanent=" + permanent
				+ ", dateOfBirth=" + dateOfBirth + ", department=" + department + ", skills=" + skills + "]";
	}
	public static Logger getLogger() {
		return LOGGER;
	}
	
}
